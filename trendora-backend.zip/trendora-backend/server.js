/**
 * Trendora backend
 * ------------------------------------------------------------------
 * A small Express API + static file server, backed by a plain JSON
 * file (db.json) instead of a database engine — easy to run anywhere
 * with just Node, and easy to swap for Postgres/Mongo later without
 * changing the route shapes below.
 *
 * Run:
 *   npm install
 *   npm start
 *   -> open http://localhost:4000            (the shopping app)
 *   -> open http://localhost:4000/admin.html (the admin dashboard)
 *
 * Admin writes (POST/PUT/DELETE on products, brands, categories) require
 * the header:  x-admin-key: <ADMIN_KEY>
 * Default ADMIN_KEY is "trendora-admin" — change it via env var before
 * you deploy this anywhere real:  ADMIN_KEY=something-secret npm start
 * ------------------------------------------------------------------
 */
const express = require('express');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 4000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'trendora-admin';
const DB_PATH = path.join(__dirname, 'db.json');

// ---- tiny JSON "database" -------------------------------------------------
function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const seed = fs.readFileSync(path.join(__dirname, 'db.seed.json'), 'utf8');
    fs.writeFileSync(DB_PATH, seed);
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}
let db = loadDB();

function nextId(prefix, list) {
  let n = list.length + 1;
  let id = prefix + n;
  while (list.some((x) => x.id === id)) { n++; id = prefix + n; }
  return id;
}

// ---- app --------------------------------------------------------------
const app = express();
app.use(express.json());

// CORS (harmless to leave on even when same-origin; useful if you ever
// host the frontend separately from this API)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type, x-admin-key');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

function requireAdmin(req, res, next) {
  if (req.get('x-admin-key') !== ADMIN_KEY) {
    return res.status(401).json({ error: 'Missing or invalid x-admin-key header' });
  }
  next();
}

// ---- Products ---------------------------------------------------------
app.get('/api/products', (req, res) => res.json(db.products));

app.get('/api/products/:id', (req, res) => {
  const p = db.products.find((x) => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

app.post('/api/products', requireAdmin, (req, res) => {
  const body = req.body || {};
  if (!body.name || !body.cat || body.price == null) {
    return res.status(400).json({ error: 'name, cat and price are required' });
  }
  const product = {
    id: nextId('p', db.products),
    name: body.name,
    cat: body.cat,
    price: Number(body.price),
    old: body.old ? Number(body.old) : null,
    rating: body.rating != null ? Number(body.rating) : 4.5,
    revs: body.revs != null ? Number(body.revs) : 0,
    tag: body.tag || null,
    sizes: body.sizes || null,
    colors: body.colors || null,
    seed: body.seed != null ? Number(body.seed) : Math.floor(Math.random() * 8),
    desc: body.desc || '',
    stock: body.stock !== false,
    brandId: body.brandId || null,
  };
  db.products.push(product);
  saveDB(db);
  res.status(201).json(product);
});

app.put('/api/products/:id', requireAdmin, (req, res) => {
  const idx = db.products.findIndex((x) => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.products[idx] = { ...db.products[idx], ...req.body, id: db.products[idx].id };
  saveDB(db);
  res.json(db.products[idx]);
});

app.delete('/api/products/:id', requireAdmin, (req, res) => {
  const before = db.products.length;
  db.products = db.products.filter((x) => x.id !== req.params.id);
  if (db.products.length === before) return res.status(404).json({ error: 'Not found' });
  saveDB(db);
  res.status(204).end();
});

// ---- Brands -------------------------------------------------------------
app.get('/api/brands', (req, res) => res.json(db.brands));

app.post('/api/brands', requireAdmin, (req, res) => {
  const name = (req.body || {}).name;
  if (!name) return res.status(400).json({ error: 'name is required' });
  const brand = { id: nextId('b', db.brands), name };
  db.brands.push(brand);
  saveDB(db);
  res.status(201).json(brand);
});

app.put('/api/brands/:id', requireAdmin, (req, res) => {
  const idx = db.brands.findIndex((x) => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.brands[idx] = { ...db.brands[idx], ...req.body, id: db.brands[idx].id };
  saveDB(db);
  res.json(db.brands[idx]);
});

app.delete('/api/brands/:id', requireAdmin, (req, res) => {
  const before = db.brands.length;
  db.brands = db.brands.filter((x) => x.id !== req.params.id);
  if (db.brands.length === before) return res.status(404).json({ error: 'Not found' });
  saveDB(db);
  res.status(204).end();
});

// ---- Categories -----------------------------------------------------------
app.get('/api/categories', (req, res) => res.json(db.categories));

app.post('/api/categories', requireAdmin, (req, res) => {
  const { id, name, glyph } = req.body || {};
  if (!id || !name) return res.status(400).json({ error: 'id and name are required' });
  if (db.categories.some((c) => c.id === id)) return res.status(409).json({ error: 'Category id already exists' });
  const cat = { id, name, glyph: glyph || name[0].toUpperCase() };
  db.categories.push(cat);
  saveDB(db);
  res.status(201).json(cat);
});

app.delete('/api/categories/:id', requireAdmin, (req, res) => {
  const before = db.categories.length;
  db.categories = db.categories.filter((x) => x.id !== req.params.id);
  if (db.categories.length === before) return res.status(404).json({ error: 'Not found' });
  saveDB(db);
  res.status(204).end();
});

// ---- Orders -------------------------------------------------------------
app.get('/api/orders', requireAdmin, (req, res) => res.json(db.orders));

app.post('/api/orders', (req, res) => {
  const order = {
    id: nextId('TR-', db.orders).replace('TR-', 'TR-8') + Math.floor(Math.random() * 900 + 100),
    createdAt: new Date().toISOString(),
    status: 'Order Confirmed',
    ...req.body,
  };
  db.orders.unshift(order);
  saveDB(db);
  res.status(201).json(order);
});

app.put('/api/orders/:id/status', requireAdmin, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  order.status = (req.body || {}).status || order.status;
  saveDB(db);
  res.json(order);
});

// ---- Stats (for the admin dashboard) --------------------------------------
app.get('/api/stats', requireAdmin, (req, res) => {
  const revenue = db.orders.reduce((sum, o) => sum + (o.total || 0), 0);
  res.json({
    products: db.products.length,
    brands: db.brands.length,
    orders: db.orders.length,
    revenue,
  });
});

// ---- static frontend --------------------------------------------------
const PUBLIC_DIR = path.join(__dirname, 'public');
app.use(express.static(PUBLIC_DIR));
app.get('/', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

app.listen(PORT, () => {
  console.log(`\n  Trendora backend running:`);
  console.log(`  → Shop:  http://localhost:${PORT}`);
  console.log(`  → Admin: http://localhost:${PORT}/admin.html`);
  console.log(`  → Admin key: ${ADMIN_KEY}\n`);
});
