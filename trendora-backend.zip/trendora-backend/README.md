# Trendora — backend + installable app

This folder contains:
- `server.js` + `db.json` / `db.seed.json` — the API and its file-based database
- `public/index.html` — the shopping app (customer-facing)
- `public/admin.html` — the admin dashboard (add/edit products & brands, manage orders)
- `public/manifest.json`, `public/sw.js`, `public/icons/` — makes the app installable on a phone

## 1. Run it locally

Requires [Node.js](https://nodejs.org) 18+.

```bash
npm install
npm start
```

Then open:
- **Shop:** http://localhost:4000
- **Admin:** http://localhost:4000/admin.html — default admin key is `trendora-admin` (change it, see below)

The app and admin panel are served from the same origin as the API, so there's nothing to configure — `index.html` talks to `/api/...` automatically. If `server.js` isn't running, `index.html` still works on its own with its built-in sample data (it fails over silently).

## 2. Add products & brands

Open `/admin.html`, enter the admin key in the top-right box, and:
- **Brands tab** → add a brand name (e.g. "Nordic Form") — it becomes selectable everywhere immediately.
- **Products tab** → fill in name, category, brand, price, optional sale price, tag (New/Trending/Bestseller), sizes, colors, description → Add Product.
- **Categories tab** → add a whole new department (e.g. "Fine Jewelry") if the 9 built-in ones aren't enough.
- **Orders tab** → see orders placed in the shop app and move them through the fulfillment stages (Confirmed → Processing → Shipped → Out for Delivery → Delivered) — the customer's order-tracking screen reflects whatever status you set here.

Everything is saved to `db.json` on disk — it persists across restarts. Delete `db.json` and restart the server to reset back to the sample catalog (`db.seed.json`).

**Change the admin key before you show this to anyone else:**
```bash
ADMIN_KEY=something-only-you-know npm start
```

## 3. Put it on your phone as an app

A phone can only "install" something served over a URL (not a file sitting on your computer), so you need to get this server online first — either on your home network or on the internet.

**Quickest — same WiFi network:**
1. Run `npm start` on your computer.
2. Find your computer's local IP (e.g. `192.168.1.42`) — on Mac: System Settings → Wi-Fi → Details; on Windows: `ipconfig`.
3. On your phone (same WiFi), open `http://192.168.1.42:4000` in Safari (iPhone) or Chrome (Android).
4. **iPhone:** tap Share → *Add to Home Screen*.
   **Android/Chrome:** tap the ⋮ menu → *Add to Home screen* / *Install app*.
5. It now opens full-screen from your home screen like a native app, with its own icon.

**To access it from anywhere (not just home WiFi)** you need to host it publicly. Free options that work well for this kind of small Node app:
- [Render](https://render.com) — connect a GitHub repo, "New Web Service", build command `npm install`, start command `npm start`.
- [Railway](https://railway.app) — similar, one-click deploy from a repo.
- [Fly.io](https://fly.io) — `fly launch` in this folder.

Any of these gives you a public `https://your-app.onrender.com` URL — open that on your phone and "Add to Home Screen" the same way. Set the `ADMIN_KEY` environment variable in whichever host's dashboard before you deploy.

## 4. Swapping in a real database later

Every route in `server.js` reads/writes through `loadDB()` / `saveDB()`, which just read/write `db.json`. When you outgrow a JSON file (many products, multiple admins, concurrent writes), swap those two functions for calls to Postgres/MongoDB/etc — the route handlers and the frontend don't need to change, since they only care about the `/api/...` JSON shapes, not how they're stored.

## What's still simplified

This is a working prototype, not a production store — before taking real orders/payments you'd still want:
- Real authentication (the login/signup screens are currently mocked)
- A real payment processor (Stripe, etc.) instead of the mock payment-method selector
- Image uploads for products (currently each product renders as a generated color tile, not a photo)
- Input validation / rate limiting / HTTPS on the API
